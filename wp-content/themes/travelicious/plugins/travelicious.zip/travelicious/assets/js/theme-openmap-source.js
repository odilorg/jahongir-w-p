var travelicious_openmap_source_arr = [];

travelicious_openmap_source_arr[0] = ["https://a.tile.openstreetmap.org/${z}/${x}/${y}.png",
            "https://b.tile.openstreetmap.org/${z}/${x}/${y}.png",
            "https://c.tile.openstreetmap.org/${z}/${x}/${y}.png"
            ];
            
travelicious_openmap_source_arr[1] = ["https://a.tile.openstreetmap.org/${z}/${x}/${y}.png",
            "https://b.tile.openstreetmap.org/${z}/${x}/${y}.png",
            "https://c.tile.openstreetmap.org/${z}/${x}/${y}.png"
            ];
        
travelicious_openmap_source_arr[2] = [
            "https://maps.wikimedia.org/osm-intl/${z}/${x}/${y}.png"
            ];

travelicious_openmap_source_arr[3] = [
            "http://a.tile.openstreetmap.fr/hot/${z}/${x}/${y}.png",
            "http://b.tile.openstreetmap.fr/hot/${z}/${x}/${y}.png",
            "http://c.tile.openstreetmap.fr/hot/${z}/${x}/${y}.png"
            ];

travelicious_openmap_source_arr[4] = [
            "https://stamen-tiles.a.ssl.fastly.net/watercolor/${z}/${x}/${y}.jpg",
            "https://stamen-tiles.a.ssl.fastly.net/watercolor/${z}/${x}/${y}.jpg",
            "https://stamen-tiles.a.ssl.fastly.net/watercolor/${z}/${x}/${y}.jpg"
            ];

travelicious_openmap_source_arr[5] = [
            "https://stamen-tiles.a.ssl.fastly.net/terrain/${z}/${x}/${y}.jpg",
            "https://stamen-tiles.a.ssl.fastly.net/terrain/${z}/${x}/${y}.jpg",
            "https://stamen-tiles.a.ssl.fastly.net/terrain/${z}/${x}/${y}.jpg"  
            ];
            
travelicious_openmap_source_arr[6] = [
            "https://stamen-tiles.a.ssl.fastly.net/toner/${z}/${x}/${y}.png",
            "https://stamen-tiles.a.ssl.fastly.net/toner/${z}/${x}/${y}.png",
            "https://stamen-tiles.a.ssl.fastly.net/toner/${z}/${x}/${y}.png"  
            ];
            
travelicious_openmap_source_arr[7] = [
            "https://cartodb-basemaps-a.global.ssl.fastly.net/dark_all/${z}/${x}/${y}.png",
            "https://cartodb-basemaps-b.global.ssl.fastly.net/dark_all/${z}/${x}/${y}.png",
            "https://cartodb-basemaps-c.global.ssl.fastly.net/dark_all/${z}/${x}/${y}.png"
            ];
                                
travelicious_openmap_source_arr[8] = [
            "https://cartodb-basemaps-a.global.ssl.fastly.net/light_all/${z}/${x}/${y}.png",
            "https://cartodb-basemaps-b.global.ssl.fastly.net/light_all/${z}/${x}/${y}.png",
            "https://cartodb-basemaps-c.global.ssl.fastly.net/light_all/${z}/${x}/${y}.png"
            ];                            





